Zheng Yin
Seng474
In this assignment, the problem is how to define the algorthm work which every picture look like same. There should be a better way to present the 
3d dataset which I did not understand the 3d dataset.
I check the completness score but I forgot how to calculate the score. 