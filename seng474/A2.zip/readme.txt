Zheng Yin
Seng474
In this Assignment, the main problem is time, training on dataset need a lot of time which is unexpacted. The Gaussian method take 
an hour to training which lead to I do not have enough information to mention in part 4. If we have some information about speed up
the dataset train, it will be better.
