Zheng Yin
In the assignment code, I use Google Colab which need a function to load the csv to google drive.
In the first part I copy the lab 1 function of decision tree, and the dtree_grid_search function.
For random forest, I just create a function base on RandomForestClassifier and make a lot test.
For Neural network part, I still make a function and covert to several mlp to make the chart. 
Sometime the df function do not work well an cause problem, I think the problem is from the dataset I use which may include some overstack data.